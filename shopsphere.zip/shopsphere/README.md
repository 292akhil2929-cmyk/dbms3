# ShopSphere — E-Commerce Platform
### CS F212 Database Systems Assignment | BITS Pilani Dubai

---

## Team Setup (Group of 5)
- Student 1: DB Design + Schema + Normalization
- Student 2: Backend API (Products, Categories)
- Student 3: Backend API (Orders, Cart, Checkout)
- Student 4: Frontend (Shop UI, Product Pages)
- Student 5: Admin Dashboard + Analytics

---

## Tech Stack
| Layer | Technology |
|-------|-----------|
| Database | **MySQL 8.0** |
| Backend | **Node.js + Express** |
| Frontend | **HTML/CSS/JS** (Vanilla SPA) |
| Auth | **JWT (jsonwebtoken)** |
| Password | **bcrypt** |

---

## Database Features Implemented
### Tables (10 fully normalized to BCNF)
- `USERS`, `ADDRESSES`, `CATEGORIES`, `PRODUCTS`, `PRODUCT_IMAGES`
- `ORDERS`, `ORDER_ITEMS`, `PAYMENTS`, `REVIEWS`, `CART_ITEMS`, `COUPONS`

### Triggers (6 triggers)
| Trigger | Event | Action |
|---------|-------|--------|
| `trg_decrease_stock` | AFTER INSERT on ORDER_ITEMS | Decreases product stock |
| `trg_restore_stock_on_cancel` | AFTER UPDATE on ORDERS | Restores stock if cancelled |
| `trg_update_avg_rating_insert` | AFTER INSERT on REVIEWS | Recalculates avg_rating |
| `trg_update_avg_rating_delete` | AFTER DELETE on REVIEWS | Recalculates avg_rating |
| `trg_increment_coupon_use` | AFTER INSERT on ORDERS | Increments coupon used_count |
| `trg_prevent_negative_stock` | BEFORE INSERT on ORDER_ITEMS | Prevents over-ordering |

### Stored Procedures (4 procedures)
- `sp_place_order` — Full checkout flow with coupon validation, transaction
- `sp_top_selling_products` — Top N products by units sold
- `sp_user_order_history` — All orders with items for a user
- `sp_dashboard_stats` — Admin dashboard KPIs

### Views (3 views)
- `vw_product_catalog` — Products with category and primary image
- `vw_order_summary` — Orders with customer info and item count
- `vw_revenue_by_category` — Revenue breakdown by category

### Complex Queries
- **Correlated subquery**: Products priced above their category average
- **Nested subquery**: Customers who spent above the average user spend
- **Multi-join queries**: Order details with product, address, payment info
- **Aggregate + HAVING**: Revenue analytics per category

### Normalization
All tables are in **BCNF**:
- No partial dependencies (all non-key attributes depend on whole PK)
- No transitive dependencies
- `ADDRESSES` separated from `USERS` (no address columns on users)
- `PRODUCT_IMAGES` separated from `PRODUCTS` (multi-valued attribute)
- `ORDER_ITEMS` bridges ORDERS and PRODUCTS with its own price snapshot
- `PAYMENTS` separated from `ORDERS` (different entity)
- `COUPONS` normalized (discount logic kept in one table)

---

## Setup Instructions

### Prerequisites
- MySQL 8.0+
- Node.js 18+
- npm

### Step 1: MySQL Setup
```sql
-- In MySQL Workbench or CLI:
mysql -u root -p < backend/db/schema.sql
```

### Step 2: Backend Setup
```bash
cd backend
cp .env.example .env
# Edit .env and set your MySQL password

npm install
node server.js
```

### Step 3: Access
Open `http://localhost:3000` in your browser.

**Demo accounts (after running schema.sql with sample data):**
- Admin: `admin@shopsphere.com`
- Customer: `alice@example.com`

**Note:** The sample data uses hashed passwords. For demo login, register a new account or update the password hashes using:
```sql
-- Run in MySQL to set password 'password123' for demo users
UPDATE USERS SET password_hash = '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi' WHERE email = 'alice@example.com';
UPDATE USERS SET password_hash = '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi' WHERE email = 'admin@shopsphere.com';
```
(The hash above is for 'password' — change to any bcrypt hash you want)

---

## API Endpoints

### Auth
- `POST /api/auth/register`
- `POST /api/auth/login`

### Products
- `GET /api/products?search=&category_id=&min_price=&max_price=&sort=&page=&limit=`
- `GET /api/products/:id`
- `POST /api/products` (admin)
- `PATCH /api/products/:id` (admin)
- `DELETE /api/products/:id` (admin, soft delete)

### Cart
- `GET /api/cart`
- `POST /api/cart`
- `PATCH /api/cart/:cart_id`
- `DELETE /api/cart/:cart_id`

### Orders
- `POST /api/orders/checkout` (calls sp_place_order)
- `GET /api/orders`
- `GET /api/orders/:id`
- `PATCH /api/orders/:id/status` (admin)
- `GET /api/orders/admin/all` (admin)

### Reviews
- `GET /api/reviews/:product_id`
- `POST /api/reviews` (must have delivered order for product)

### Users/Admin
- `GET /api/users/profile`
- `POST /api/users/addresses`
- `GET /api/users/admin/dashboard` (calls sp_dashboard_stats)
- `GET /api/users/admin/top-products` (calls sp_top_selling_products)
- `GET /api/users/admin/revenue-by-category` (uses vw_revenue_by_category)
- `GET /api/users/admin/customers-above-avg` (nested subquery)

---

## Project Structure
```
shopsphere/
├── backend/
│   ├── db/
│   │   ├── schema.sql          ← All tables, triggers, procedures, views, sample data
│   │   └── connection.js       ← MySQL connection pool
│   ├── middleware/
│   │   └── auth.js             ← JWT authentication middleware
│   ├── routes/
│   │   ├── auth.js             ← Register & login
│   │   ├── products.js         ← Product CRUD + search + filter
│   │   ├── cart.js             ← Cart management
│   │   ├── orders.js           ← Checkout (stored procedure) + order history
│   │   ├── reviews.js          ← Product reviews
│   │   └── users.js            ← Profile, addresses, admin analytics
│   ├── server.js               ← Express app entry point
│   ├── package.json
│   └── .env.example            ← Environment config template
└── frontend/
    └── public/
        └── index.html          ← Full SPA frontend
```
