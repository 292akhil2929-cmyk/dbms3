-- ============================================================
-- ShopSphere E-Commerce Database
-- CS F212 Database Systems Assignment
-- ============================================================

CREATE DATABASE IF NOT EXISTS shopsphere CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE shopsphere;

-- ============================================================
-- TABLE DEFINITIONS (Normalized to BCNF)
-- ============================================================

CREATE TABLE IF NOT EXISTS CATEGORIES (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL UNIQUE,
    parent_id   INT DEFAULT NULL,
    description TEXT,
    CONSTRAINT fk_cat_parent FOREIGN KEY (parent_id) REFERENCES CATEGORIES(category_id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS USERS (
    user_id       INT AUTO_INCREMENT PRIMARY KEY,
    email         VARCHAR(191) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name     VARCHAR(150) NOT NULL,
    phone         VARCHAR(20),
    role          ENUM('customer','admin') NOT NULL DEFAULT 'customer',
    is_active     TINYINT(1) NOT NULL DEFAULT 1,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_users_email (email),
    INDEX idx_users_role  (role)
);

CREATE TABLE IF NOT EXISTS ADDRESSES (
    address_id  INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    full_name   VARCHAR(150) NOT NULL,
    street      VARCHAR(255) NOT NULL,
    city        VARCHAR(100) NOT NULL,
    state       VARCHAR(100),
    country     VARCHAR(100) NOT NULL DEFAULT 'UAE',
    postal_code VARCHAR(20),
    is_default  TINYINT(1) NOT NULL DEFAULT 0,
    CONSTRAINT fk_addr_user FOREIGN KEY (user_id) REFERENCES USERS(user_id) ON DELETE CASCADE,
    INDEX idx_addr_user (user_id)
);

CREATE TABLE IF NOT EXISTS PRODUCTS (
    product_id  INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name        VARCHAR(255) NOT NULL,
    description TEXT,
    price       DECIMAL(10,2) NOT NULL CHECK (price >= 0),
    stock_qty   INT NOT NULL DEFAULT 0 CHECK (stock_qty >= 0),
    avg_rating  DECIMAL(3,2) DEFAULT 0.00,
    is_active   TINYINT(1) NOT NULL DEFAULT 1,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_prod_cat FOREIGN KEY (category_id) REFERENCES CATEGORIES(category_id),
    INDEX idx_prod_cat     (category_id),
    INDEX idx_prod_price   (price),
    INDEX idx_prod_rating  (avg_rating)
);

CREATE TABLE IF NOT EXISTS PRODUCT_IMAGES (
    image_id   INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    url        VARCHAR(500) NOT NULL,
    is_primary TINYINT(1) NOT NULL DEFAULT 0,
    CONSTRAINT fk_img_prod FOREIGN KEY (product_id) REFERENCES PRODUCTS(product_id) ON DELETE CASCADE,
    INDEX idx_img_prod (product_id)
);

CREATE TABLE IF NOT EXISTS COUPONS (
    coupon_id    INT AUTO_INCREMENT PRIMARY KEY,
    code         VARCHAR(50) NOT NULL UNIQUE,
    discount_pct DECIMAL(5,2) NOT NULL CHECK (discount_pct > 0 AND discount_pct <= 100),
    expires_at   DATE NOT NULL,
    max_uses     INT NOT NULL DEFAULT 100,
    used_count   INT NOT NULL DEFAULT 0,
    is_active    TINYINT(1) NOT NULL DEFAULT 1,
    INDEX idx_coupon_code (code)
);

CREATE TABLE IF NOT EXISTS ORDERS (
    order_id     INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT NOT NULL,
    address_id   INT NOT NULL,
    coupon_id    INT DEFAULT NULL,
    subtotal     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    discount_amt DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    status       ENUM('pending','confirmed','shipped','delivered','cancelled') NOT NULL DEFAULT 'pending',
    ordered_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_order_user    FOREIGN KEY (user_id)    REFERENCES USERS(user_id),
    CONSTRAINT fk_order_addr    FOREIGN KEY (address_id) REFERENCES ADDRESSES(address_id),
    CONSTRAINT fk_order_coupon  FOREIGN KEY (coupon_id)  REFERENCES COUPONS(coupon_id) ON DELETE SET NULL,
    INDEX idx_order_user   (user_id),
    INDEX idx_order_status (status),
    INDEX idx_order_date   (ordered_at)
);

CREATE TABLE IF NOT EXISTS ORDER_ITEMS (
    item_id    INT AUTO_INCREMENT PRIMARY KEY,
    order_id   INT NOT NULL,
    product_id INT NOT NULL,
    quantity   INT NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_oi_order   FOREIGN KEY (order_id)   REFERENCES ORDERS(order_id) ON DELETE CASCADE,
    CONSTRAINT fk_oi_product FOREIGN KEY (product_id) REFERENCES PRODUCTS(product_id),
    UNIQUE KEY uq_order_product (order_id, product_id),
    INDEX idx_oi_product (product_id)
);

CREATE TABLE IF NOT EXISTS PAYMENTS (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id   INT NOT NULL UNIQUE,
    method     ENUM('credit_card','debit_card','paypal','bank_transfer','cash_on_delivery') NOT NULL,
    status     ENUM('pending','completed','failed','refunded') NOT NULL DEFAULT 'pending',
    amount     DECIMAL(10,2) NOT NULL,
    txn_ref    VARCHAR(100),
    paid_at    TIMESTAMP DEFAULT NULL,
    CONSTRAINT fk_pay_order FOREIGN KEY (order_id) REFERENCES ORDERS(order_id) ON DELETE CASCADE,
    INDEX idx_pay_status (status)
);

CREATE TABLE IF NOT EXISTS REVIEWS (
    review_id  INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT NOT NULL,
    product_id INT NOT NULL,
    rating     TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment    TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_rev_user    FOREIGN KEY (user_id)    REFERENCES USERS(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_rev_product FOREIGN KEY (product_id) REFERENCES PRODUCTS(product_id) ON DELETE CASCADE,
    UNIQUE KEY uq_user_product_review (user_id, product_id),
    INDEX idx_rev_product (product_id),
    INDEX idx_rev_rating  (rating)
);

CREATE TABLE IF NOT EXISTS CART_ITEMS (
    cart_id    INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT NOT NULL,
    product_id INT NOT NULL,
    quantity   INT NOT NULL DEFAULT 1 CHECK (quantity > 0),
    added_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_cart_user    FOREIGN KEY (user_id)    REFERENCES USERS(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_cart_product FOREIGN KEY (product_id) REFERENCES PRODUCTS(product_id) ON DELETE CASCADE,
    UNIQUE KEY uq_cart_user_product (user_id, product_id),
    INDEX idx_cart_user (user_id)
);

-- ============================================================
-- VIEWS
-- ============================================================

-- View: Product catalog with category name and primary image
CREATE OR REPLACE VIEW vw_product_catalog AS
SELECT
    p.product_id,
    p.name          AS product_name,
    c.name          AS category_name,
    p.price,
    p.stock_qty,
    p.avg_rating,
    p.is_active,
    pi.url          AS primary_image,
    p.created_at
FROM PRODUCTS p
JOIN CATEGORIES c ON p.category_id = c.category_id
LEFT JOIN PRODUCT_IMAGES pi ON pi.product_id = p.product_id AND pi.is_primary = 1;

-- View: Order summary with customer info
CREATE OR REPLACE VIEW vw_order_summary AS
SELECT
    o.order_id,
    u.full_name      AS customer_name,
    u.email,
    o.status,
    o.subtotal,
    o.discount_amt,
    o.total_amount,
    o.ordered_at,
    COUNT(oi.item_id) AS item_count
FROM ORDERS o
JOIN USERS u        ON o.user_id  = u.user_id
JOIN ORDER_ITEMS oi ON o.order_id = oi.order_id
GROUP BY o.order_id, u.full_name, u.email, o.status,
         o.subtotal, o.discount_amt, o.total_amount, o.ordered_at;

-- View: Revenue by category
CREATE OR REPLACE VIEW vw_revenue_by_category AS
SELECT
    c.name            AS category_name,
    COUNT(DISTINCT o.order_id) AS total_orders,
    SUM(oi.quantity)  AS units_sold,
    SUM(oi.quantity * oi.unit_price) AS revenue
FROM ORDER_ITEMS oi
JOIN PRODUCTS p  ON oi.product_id = p.product_id
JOIN CATEGORIES c ON p.category_id = c.category_id
JOIN ORDERS o    ON oi.order_id   = o.order_id
WHERE o.status != 'cancelled'
GROUP BY c.category_id, c.name;

-- ============================================================
-- TRIGGERS
-- ============================================================

DELIMITER $$

-- Trigger 1: Decrease stock when order item is created
CREATE TRIGGER trg_decrease_stock
AFTER INSERT ON ORDER_ITEMS
FOR EACH ROW
BEGIN
    UPDATE PRODUCTS
    SET stock_qty = stock_qty - NEW.quantity
    WHERE product_id = NEW.product_id;
END$$

-- Trigger 2: Restore stock when order is cancelled
CREATE TRIGGER trg_restore_stock_on_cancel
AFTER UPDATE ON ORDERS
FOR EACH ROW
BEGIN
    IF NEW.status = 'cancelled' AND OLD.status != 'cancelled' THEN
        UPDATE PRODUCTS p
        JOIN ORDER_ITEMS oi ON p.product_id = oi.product_id
        SET p.stock_qty = p.stock_qty + oi.quantity
        WHERE oi.order_id = NEW.order_id;
    END IF;
END$$

-- Trigger 3: Recalculate product avg_rating after a review is inserted
CREATE TRIGGER trg_update_avg_rating_insert
AFTER INSERT ON REVIEWS
FOR EACH ROW
BEGIN
    UPDATE PRODUCTS
    SET avg_rating = (
        SELECT AVG(rating) FROM REVIEWS WHERE product_id = NEW.product_id
    )
    WHERE product_id = NEW.product_id;
END$$

-- Trigger 4: Recalculate product avg_rating after a review is deleted
CREATE TRIGGER trg_update_avg_rating_delete
AFTER DELETE ON REVIEWS
FOR EACH ROW
BEGIN
    UPDATE PRODUCTS
    SET avg_rating = COALESCE(
        (SELECT AVG(rating) FROM REVIEWS WHERE product_id = OLD.product_id),
        0
    )
    WHERE product_id = OLD.product_id;
END$$

-- Trigger 5: Increment coupon used_count on order creation
CREATE TRIGGER trg_increment_coupon_use
AFTER INSERT ON ORDERS
FOR EACH ROW
BEGIN
    IF NEW.coupon_id IS NOT NULL THEN
        UPDATE COUPONS
        SET used_count = used_count + 1
        WHERE coupon_id = NEW.coupon_id;
    END IF;
END$$

-- Trigger 6: Prevent stock going below zero
CREATE TRIGGER trg_prevent_negative_stock
BEFORE INSERT ON ORDER_ITEMS
FOR EACH ROW
BEGIN
    DECLARE current_stock INT;
    SELECT stock_qty INTO current_stock FROM PRODUCTS WHERE product_id = NEW.product_id;
    IF current_stock < NEW.quantity THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Insufficient stock for this product';
    END IF;
END$$

DELIMITER ;

-- ============================================================
-- STORED PROCEDURES
-- ============================================================

DELIMITER $$

-- Procedure 1: Place an order (full checkout flow)
CREATE PROCEDURE sp_place_order(
    IN  p_user_id    INT,
    IN  p_address_id INT,
    IN  p_coupon_code VARCHAR(50),
    OUT p_order_id   INT,
    OUT p_message    VARCHAR(255)
)
BEGIN
    DECLARE v_coupon_id    INT DEFAULT NULL;
    DECLARE v_discount_pct DECIMAL(5,2) DEFAULT 0;
    DECLARE v_subtotal     DECIMAL(10,2) DEFAULT 0;
    DECLARE v_discount_amt DECIMAL(10,2) DEFAULT 0;
    DECLARE v_total        DECIMAL(10,2) DEFAULT 0;
    DECLARE v_cart_count   INT DEFAULT 0;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_message = 'Order placement failed due to a database error.';
        SET p_order_id = -1;
    END;

    -- Validate cart is not empty
    SELECT COUNT(*) INTO v_cart_count FROM CART_ITEMS WHERE user_id = p_user_id;
    IF v_cart_count = 0 THEN
        SET p_message = 'Cart is empty';
        SET p_order_id = -1;
        LEAVE sp_place_order;
    END IF;

    -- Validate and apply coupon if provided
    IF p_coupon_code IS NOT NULL AND p_coupon_code != '' THEN
        SELECT coupon_id, discount_pct
        INTO v_coupon_id, v_discount_pct
        FROM COUPONS
        WHERE code = p_coupon_code
          AND is_active = 1
          AND expires_at >= CURDATE()
          AND used_count < max_uses
        LIMIT 1;

        IF v_coupon_id IS NULL THEN
            SET p_message = 'Invalid or expired coupon code';
            SET p_order_id = -1;
            LEAVE sp_place_order;
        END IF;
    END IF;

    -- Calculate subtotal from cart
    SELECT SUM(ci.quantity * p.price)
    INTO v_subtotal
    FROM CART_ITEMS ci
    JOIN PRODUCTS p ON ci.product_id = p.product_id
    WHERE ci.user_id = p_user_id;

    SET v_discount_amt = ROUND(v_subtotal * v_discount_pct / 100, 2);
    SET v_total        = v_subtotal - v_discount_amt;

    START TRANSACTION;

    -- Create the order
    INSERT INTO ORDERS (user_id, address_id, coupon_id, subtotal, discount_amt, total_amount, status)
    VALUES (p_user_id, p_address_id, v_coupon_id, v_subtotal, v_discount_amt, v_total, 'confirmed');

    SET p_order_id = LAST_INSERT_ID();

    -- Copy cart items to order items (trigger handles stock deduction)
    INSERT INTO ORDER_ITEMS (order_id, product_id, quantity, unit_price)
    SELECT p_order_id, ci.product_id, ci.quantity, p.price
    FROM CART_ITEMS ci
    JOIN PRODUCTS p ON ci.product_id = p.product_id
    WHERE ci.user_id = p_user_id;

    -- Clear the cart
    DELETE FROM CART_ITEMS WHERE user_id = p_user_id;

    COMMIT;
    SET p_message = 'Order placed successfully';
END$$

-- Procedure 2: Get top N best-selling products
CREATE PROCEDURE sp_top_selling_products(IN p_limit INT)
BEGIN
    SELECT
        p.product_id,
        p.name,
        c.name           AS category,
        SUM(oi.quantity) AS units_sold,
        SUM(oi.quantity * oi.unit_price) AS revenue,
        p.avg_rating
    FROM ORDER_ITEMS oi
    JOIN PRODUCTS p   ON oi.product_id  = p.product_id
    JOIN CATEGORIES c ON p.category_id  = c.category_id
    JOIN ORDERS o     ON oi.order_id    = o.order_id
    WHERE o.status != 'cancelled'
    GROUP BY p.product_id, p.name, c.name, p.avg_rating
    ORDER BY units_sold DESC
    LIMIT p_limit;
END$$

-- Procedure 3: Get user order history with items
CREATE PROCEDURE sp_user_order_history(IN p_user_id INT)
BEGIN
    SELECT
        o.order_id,
        o.status,
        o.total_amount,
        o.ordered_at,
        p.name           AS product_name,
        oi.quantity,
        oi.unit_price,
        (oi.quantity * oi.unit_price) AS line_total
    FROM ORDERS o
    JOIN ORDER_ITEMS oi ON o.order_id   = oi.order_id
    JOIN PRODUCTS p     ON oi.product_id = p.product_id
    WHERE o.user_id = p_user_id
    ORDER BY o.ordered_at DESC;
END$$

-- Procedure 4: Admin dashboard stats
CREATE PROCEDURE sp_dashboard_stats()
BEGIN
    SELECT
        (SELECT COUNT(*) FROM USERS WHERE role = 'customer') AS total_customers,
        (SELECT COUNT(*) FROM ORDERS WHERE status != 'cancelled') AS total_orders,
        (SELECT COALESCE(SUM(total_amount),0) FROM ORDERS WHERE status = 'delivered') AS total_revenue,
        (SELECT COUNT(*) FROM PRODUCTS WHERE is_active = 1) AS active_products,
        (SELECT COUNT(*) FROM ORDERS WHERE status = 'pending') AS pending_orders,
        (SELECT COUNT(*) FROM PRODUCTS WHERE stock_qty < 5 AND is_active = 1) AS low_stock_products;
END$$

DELIMITER ;

-- ============================================================
-- SAMPLE DATA
-- ============================================================

INSERT INTO CATEGORIES (name, parent_id, description) VALUES
('Electronics',   NULL, 'Gadgets and electronic devices'),
('Fashion',       NULL, 'Clothing, accessories, and footwear'),
('Home & Kitchen',NULL, 'Furniture, appliances, and home essentials'),
('Books',         NULL, 'Physical and digital books'),
('Sports',        NULL, 'Sports equipment and activewear'),
('Phones',        1, 'Smartphones and accessories'),
('Laptops',       1, 'Laptops and notebooks'),
('Men Clothing',  2, 'Shirts, trousers, and jackets'),
('Women Clothing',2, 'Dresses, tops, and skirts'),
('Kitchen Appliances', 3, 'Blenders, microwaves, and more');

INSERT INTO USERS (email, password_hash, full_name, phone, role) VALUES
('admin@shopsphere.com', '$2b$10$hashed_admin_pw', 'Admin User', '+971501234567', 'admin'),
('alice@example.com',    '$2b$10$hashed_alice_pw', 'Alice Johnson', '+971502345678', 'customer'),
('bob@example.com',      '$2b$10$hashed_bob_pw',   'Bob Smith',    '+971503456789', 'customer'),
('carol@example.com',    '$2b$10$hashed_carol_pw', 'Carol Davis',  '+971504567890', 'customer'),
('dave@example.com',     '$2b$10$hashed_dave_pw',  'Dave Wilson',  '+971505678901', 'customer');

INSERT INTO ADDRESSES (user_id, full_name, street, city, state, country, postal_code, is_default) VALUES
(2, 'Alice Johnson',  '123 Sheikh Zayed Rd', 'Dubai',      'Dubai', 'UAE', '00000', 1),
(3, 'Bob Smith',      '45 Corniche Rd',       'Abu Dhabi',  'AD',    'UAE', '00000', 1),
(4, 'Carol Davis',    '78 Al Wahda St',       'Sharjah',    'SHJ',   'UAE', '00000', 1),
(5, 'Dave Wilson',    '12 Clock Tower Sq',    'Al Ain',     'AD',    'UAE', '00000', 1);

INSERT INTO PRODUCTS (category_id, name, description, price, stock_qty, avg_rating) VALUES
(6,  'iPhone 15 Pro',       'Latest Apple flagship with titanium body',          4999.00, 50,  4.8),
(6,  'Samsung Galaxy S24',  'Premium Android smartphone',                        3999.00, 75,  4.7),
(6,  'OnePlus 12',          'Flagship killer with Snapdragon 8 Gen 3',           2999.00, 60,  4.6),
(7,  'MacBook Pro 14"',     'M3 Pro chip, 18GB RAM, stunning Liquid Retina XDR', 9999.00, 30,  4.9),
(7,  'Dell XPS 15',         'Intel Core i9, OLED display, premium build',        7999.00, 25,  4.6),
(7,  'Lenovo ThinkPad X1',  'Business ultrabook with excellent keyboard',         6499.00, 40,  4.5),
(8,  'Levi\'s Slim Fit Jeans', 'Classic 511 slim fit, dark blue wash',           199.00, 200,  4.4),
(9,  'Nike Air Max Hoodie', 'Oversized fit, cotton blend, multiple colors',       149.00, 300,  4.3),
(10, 'Instant Pot Duo 7-in-1', 'Pressure cooker, slow cooker, rice cooker',      349.00, 80,   4.7),
(10, 'Ninja Air Fryer',     '5.5L capacity, 4-in-1 functionality',               249.00, 100,  4.6),
(4,  'Clean Code',          'Robert C. Martin - Software craftsmanship guide',    89.00, 500,  4.8),
(4,  'System Design Interview', 'Alex Xu - Comprehensive system design guide',   99.00, 400,   4.7),
(5,  'Yonex Badminton Racket', 'Nanoflare 700 - Offensive attacking frame',      450.00, 60,   4.7),
(5,  'Nike Running Shoes',  'React Infinity Run Flyknit, cushioned sole',         499.00, 120,  4.5),
(1,  'Sony WH-1000XM5',     'Industry-leading noise cancelling headphones',       999.00, 90,   4.9);

INSERT INTO PRODUCT_IMAGES (product_id, url, is_primary) VALUES
(1,  'https://picsum.photos/seed/iphone/400/400',    1),
(2,  'https://picsum.photos/seed/samsung/400/400',   1),
(3,  'https://picsum.photos/seed/oneplus/400/400',   1),
(4,  'https://picsum.photos/seed/macbook/400/400',   1),
(5,  'https://picsum.photos/seed/dell/400/400',      1),
(6,  'https://picsum.photos/seed/lenovo/400/400',    1),
(7,  'https://picsum.photos/seed/levis/400/400',     1),
(8,  'https://picsum.photos/seed/nike/400/400',      1),
(9,  'https://picsum.photos/seed/instapot/400/400',  1),
(10, 'https://picsum.photos/seed/airfryer/400/400',  1),
(11, 'https://picsum.photos/seed/cleancode/400/400', 1),
(12, 'https://picsum.photos/seed/sysdesign/400/400', 1),
(13, 'https://picsum.photos/seed/yonex/400/400',     1),
(14, 'https://picsum.photos/seed/nikerun/400/400',   1),
(15, 'https://picsum.photos/seed/sony/400/400',      1);

INSERT INTO COUPONS (code, discount_pct, expires_at, max_uses) VALUES
('WELCOME10', 10.00, '2026-12-31', 1000),
('SUMMER20',  20.00, '2026-06-30', 500),
('FLASH50',   50.00, '2026-04-30', 50),
('VIP30',     30.00, '2026-12-31', 200);

-- ============================================================
-- COMPLEX QUERIES (for assignment demonstration)
-- ============================================================

-- Query 1: Correlated subquery - Products with above-average price in their category
-- SELECT p.name, p.price, c.name AS category
-- FROM PRODUCTS p
-- JOIN CATEGORIES c ON p.category_id = c.category_id
-- WHERE p.price > (
--     SELECT AVG(p2.price)
--     FROM PRODUCTS p2
--     WHERE p2.category_id = p.category_id
-- );

-- Query 2: Nested subquery - Customers who spent more than the average order value
-- SELECT u.full_name, u.email, SUM(o.total_amount) AS total_spent
-- FROM USERS u
-- JOIN ORDERS o ON u.user_id = o.user_id
-- WHERE o.status = 'delivered'
-- GROUP BY u.user_id
-- HAVING SUM(o.total_amount) > (
--     SELECT AVG(order_total)
--     FROM (
--         SELECT SUM(total_amount) AS order_total
--         FROM ORDERS
--         WHERE status = 'delivered'
--         GROUP BY user_id
--     ) AS user_totals
-- );

-- Query 3: Window function - Rank products by sales within each category
-- SELECT
--     product_name, category_name, units_sold,
--     RANK() OVER (PARTITION BY category_name ORDER BY units_sold DESC) AS rank_in_category
-- FROM vw_revenue_by_category;
